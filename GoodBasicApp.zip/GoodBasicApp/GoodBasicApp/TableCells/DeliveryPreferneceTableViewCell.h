//
//  DeliveryPreferneceTableViewCell.h
//  GoodBasicApp
//
//  Created by Bhumesh on 02/03/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeliveryPreferneceTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btnPressedLabel;
@property (strong, nonatomic) IBOutlet UILabel *lblDeliveryAddress;

@end
