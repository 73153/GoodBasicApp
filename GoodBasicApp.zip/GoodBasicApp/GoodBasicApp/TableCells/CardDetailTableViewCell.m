//
//  CardDetailTableViewCell.m
//  GoodBasicApp
//
//  Created by GoodBasicApp..... on 3/11/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import "CardDetailTableViewCell.h"

@implementation CardDetailTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
