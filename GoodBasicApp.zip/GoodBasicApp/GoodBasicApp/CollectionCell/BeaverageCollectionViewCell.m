//
//  BeaverageCollectionViewCell.m
//  GoodBasicApp
//
//  Created by GoodBasicApp..... on 1/4/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import "BeaverageCollectionViewCell.h"

@implementation BeaverageCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
