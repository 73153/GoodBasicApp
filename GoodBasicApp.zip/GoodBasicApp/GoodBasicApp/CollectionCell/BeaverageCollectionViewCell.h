//
//  BeaverageCollectionViewCell.h
//  GoodBasicApp
//
//  Created by GoodBasicApp..... on 1/4/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeaverageCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgItem;

@end
