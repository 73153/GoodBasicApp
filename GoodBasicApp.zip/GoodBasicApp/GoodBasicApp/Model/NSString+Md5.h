//
//  NSString+Md5.h
//  GoodBasicApp
//
//  Created by Bhumesh on 01/04/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Md5)

- (NSString *)MD5;
- (NSString *)md5 ;
@end
