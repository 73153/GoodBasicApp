//
//  ReferInviteFriendViewController.h
//  GoodBasicApp
//
//  Created by GoodBasicApp..... on 4/11/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReferInviteFriendViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtFriendsEmail;
@property (weak, nonatomic) IBOutlet UITextView *txtComment;

- (IBAction)btnSendEmailPressed:(id)sender;

-(void)referralMethod;


@end
