//
//  PointsViewController.h
//  GoodBasicApp
//
//  Created by GoodBasicApp..... on 1/18/16.
//  Copyright © 2016 GoodBasicApp...... All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Globals.h"
#import "CommonPopUpView.h"

@interface PointsViewController : UIViewController
{
    NSMutableArray *aryPoints;
    NSMutableArray *aryTransactionHistory;
}

@property (weak, nonatomic) IBOutlet UILabel *lblPoints;
@property(strong,nonatomic)IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *lblNoAddress;

- (IBAction)btnInvitefriendPressed:(id)sender;

-(void)referPointsMethod;

@end
